#!/bin/sh

sqlite3 -line oauth_context.db 'delete from node;'
sqlite3 -line oauth_context.db 'delete from orchestratednode;'
#sqlite3 -line oauth_context.db 'delete from provider_channel;'
#sqlite3 -line oauth_context.db 'delete from user_channel;'
