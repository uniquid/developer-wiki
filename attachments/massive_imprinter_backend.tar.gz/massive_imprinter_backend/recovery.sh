#!/bin/sh

sqlite3 -line oauth_context.db "update node set node_status = 'CREATED', imprinted_address = '', output_transaction = '' where node_status = 'IMPRINTING';"
