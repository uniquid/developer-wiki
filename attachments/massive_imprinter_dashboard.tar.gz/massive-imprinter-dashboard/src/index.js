// @flow

import React from 'react'
import ReactDOM from 'react-dom'
import configureStore from './core/store/configureStore'
import './styles/app.scss'

import Root from './core/store/root'

const store = configureStore()

ReactDOM.render(
  <Root store={store} />,
  document.getElementById('root')
)
