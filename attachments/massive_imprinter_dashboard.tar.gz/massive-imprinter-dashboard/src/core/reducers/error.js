import {
  HAS_ERROR
} from '../actions/error'

export function error (state = {}, action) {
  switch (action.type) {
    case HAS_ERROR:
      console.log(action.error)
      return action.error
    default:
      return state
  }
}
