import {
  ACTIVATE_CONNECTION,
  DEACTIVATE_CONNECTION,
  INCREMENT_TAIL,
  DECREMENT_TAIL,
  ADD_SOCKET,
  VERIFY_AUTH,
  ADD_SESSIONID,
  IS_SYNCED
} from '../actions/home'

export function home (state = {}, action) {
  switch (action.type) {
    case ACTIVATE_CONNECTION:
      return Object.assign({}, state, {
        status: action.status
      })
    case DEACTIVATE_CONNECTION:
      return Object.assign({}, state, {
        status: action.status
      })
    case ADD_SOCKET:
      return Object.assign({}, state, {
        ws: action.socket
      })
    case ADD_SESSIONID:
      return Object.assign({}, state, {
        sessionId: action.val
      })
    case VERIFY_AUTH:
      return Object.assign({}, state, {
        auth: action.auth
      })
    case IS_SYNCED:
      return Object.assign({}, state, {
        synced: action.res
      })
    default:
      return state
  }
}

export function tail (state = {}, action) {
  switch (action.type) {
    case INCREMENT_TAIL:
      return Object.assign({}, state, {
        requests: [
          ...state.requests,
          action.msg
        ]
      })
    case DECREMENT_TAIL:
      return Object.assign({}, state, {
        requests: [
          ...state.requests.slice(0, action.index),
          ...state.requests.slice(action.index + 1)
        ]
      })
    default:
      return state
  }
}
