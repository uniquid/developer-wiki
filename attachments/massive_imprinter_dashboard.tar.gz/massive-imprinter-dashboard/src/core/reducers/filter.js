import {
    UPDATE_FILTER
} from '../actions/filter'

export function filter (state = {name: '', status: ''}, action) {
  switch (action.type) {
    case UPDATE_FILTER:
      let newFilter = Object.assign({}, state)
        newFilter[action.name] = action.filter
      return newFilter

    default:
      return state
  }
}