import {
  GET_ALL_NODES,
  TOGGLE_NODE,
  TOGGLE_CONTROLLER,
  SELECT_NODE,
  TOGGLE,
  RESET_SELECTION,
  SELECT_ALL
} from '../actions/nodes'

export function nodes (state = [], action) {
  switch (action.type) {
    case GET_ALL_NODES:
      return action.nodes
    default:
      return state
  }
}

export function selectedNodes (state = [], action) {
  switch (action.type) {
    case SELECT_NODE:
      let idAlreadyExists = state.indexOf(action.node.xpub) > -1
      let chosenIds = state.slice()
      if (idAlreadyExists) {
        chosenIds = chosenIds.filter(id => id !== action.node.xpub)
      } else { chosenIds.push(action.node.xpub) }
      return chosenIds
    case RESET_SELECTION:
      return []
    case SELECT_ALL:
      let xpubs = action.nodes.map(node => node.xpub)
      return xpubs
    default:
      return state
  }
}

export function toggledControlled (state = false, action) {
  switch (action.type) {
    case TOGGLE_CONTROLLER:
    
    return action.status
    default:
      return state
  }
}