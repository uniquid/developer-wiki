import { createStore, applyMiddleware, compose } from 'redux'
import uniquidApp from '../reducers/uniquidApp'
import createLogger from 'redux-logger'
// const persistedState = {
//   nodes: []
// }

const logger = createLogger()

const configureStore = () => {
  const store = createStore(
    uniquidApp,
    compose(applyMiddleware(logger), window.devToolsExtension ? window.devToolsExtension() : f => f)
  )

  return store
}

export default configureStore
