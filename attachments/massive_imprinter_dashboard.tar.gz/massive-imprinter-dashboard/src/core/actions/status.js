export const UPDATE_STATUS = 'UPDATE_STATUS'

export const updateStatusAction = (status) => {
  return {
    type: 'UPDATE_STATUS',
    status
  }
}