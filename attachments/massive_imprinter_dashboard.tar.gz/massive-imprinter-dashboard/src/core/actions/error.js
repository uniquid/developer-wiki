export const HAS_ERROR = 'HAS_ERROR'

export const hasErrorAction = (status, icon, title, message, retry) => {
  let error = {
    status,
    icon,
    title,
    message,
    retry
  }
  return {
    type: 'HAS_ERROR',
    error
  }
}
