import React, { Component } from 'react'
import Filters from '../../components/filters/filters'
import Row from '../../components/table/row'
import ImprinterWorker from '../../services/imprinter'

class Home extends Component {
  constructor (props) {
    super(props)
    this.getAllNodes = this.getAllNodes.bind(this)
    this.filterName = this.filterName.bind(this)
    this.filterStatus = this.filterStatus.bind(this)
    this.getAllOrchestrators = this.getAllOrchestrators.bind(this)
    this.state = {
      nameFilter: '',
      statusFilter: '',
      tagFilter: [],
      sessionId: '',
      mockup: [
        { checked: false,
          name: "UIDe10f011aftaa6",
          status: "IMPRINTED",
          xpub: "tpubDBCLArUDJMTEvpzFEeB52i6bPyXtYhXidrgB78Xv4CZBVR2c3jt7CsgJAeRycaP7NuXYwQ3qvVoS1XnRK9Xs2cPYWDS8CHgFAZxzqzpucZSx"
        },
        { checked: false,
          name: "UID4e0f011afaa6",
          status: "ORCHESTRATED",
          xpub: "tpubDBCLAUDJMTEsvpzFEeB52i6bPyXtYhXidrgB78Xv4CZBVR2c3jt7CsgJAeRycaP7NuXYwQ3qvVoS1XnRK9Xs2cPYWDS8CHgFAZxzqzpucZSx"
        },
        { checked: false,
          name: "UIDee0f0411afaa6",
          status: "CREATED",
          xpub: "tpubDBCLAUDJMTEvpzFEeB52i6bPyXtYhXidrgB78Xv4CZBVR2c3jt7CsgJAeRycaP7NuXYwQ3qvVoS1XnRK9Xs2cPYWDS8CHgFAZxzqzpucZSx"
        },
        { checked: false,
          name: "UIDee0f1011BBBBfaa6",
          status: "IMPRINTED",
          xpub: "tpubDBCLAUDJMTEvtpzFEeB52i6bPyXtYhXidrgB78Xv4CZBVR2c3jt7CsgJAeRycaP7NuXYwQ3qvVoS1XnRK9Xs2cPYWDS8CHgFAZxzqzpucZSx"
        },
        { checked: false,
          name: "UICee0f011afaa6",
          status: "IMPRINTED",
          xpub: "tpubDBCLAUDJsMTEvpzFEeB52i6bPyXtYhXidrgB78Xv4CZBVR2c3jt7CsgJAeRycaP7NuXYwQ3qvVoS1XnRK9Xs2cPYWDS8CHgFAZxzqzpucZSx"
        },

      ]
    }
  }

  // NAME FILTER
  filterName (ev) {
     let _this = this
    // Il macro selettore viene settato su false
    this.props.toggleController(false)
    // I nodi selezionati in precedenza vengono settati su false
    this.props.resetSelectedNodes()
    // Aggiorno lo stato con il filtro selezionato
    this.setState({nameFilter: ev.target.value})
    this.props.updateFilter('name', ev.target.value)
  }

  filterTags (tags) {
    // this.setState({filters: {tags: tags}})
  }

  // STATUS FILTER
  filterStatus (ev) {
    let _this = this
    // Il macro selettore viene settato su false
    this.props.toggleController(false)
    // I nodi selezionati in precedenza vengono settati su false
    this.props.resetSelectedNodes()
    // Aggiorno lo stato con il filtro selezionato
    if (ev.target.value === 'ALL') { 
      this.props.updateFilter('status', "")    
      return this.setState({statusFilter: ""}) 
    }
    this.setState({statusFilter: ev.target.value})
    this.props.updateFilter('status', ev.target.value)
  }

  getAllNodes () {
    let _this = this
    ImprinterWorker.get('nodes')
    .then(function (res) {
      _this.props.getAllNodes(res.data)
      _this.props.totalNodeInfo(res.data)
    }).catch(function() {
      _this.props.hasError(true, 'icon-cross2', 'Server Error', 'We are having problems reaching the server, retry in few seconds', _this.getAllNodes)
      _this.props.getAllNodes(_this.state.mockup)
    })
  }

  getAllOrchestrators () {
    let _this = this
    ImprinterWorker.get('orchestrators')
    .then(function (res) {
        _this.props.getAllOrchestrators(res.data)
    })
    .catch (function (err){
      _this.props.hasError(true, 'icon-cross2', 'Server Error', 'We are having problems reaching the server, please retry in few seconds', _this.getAllNodes)
    }) 
  }

  componentDidMount () {
    this.getAllNodes()
    this.getAllOrchestrators()
  }

  render () {
    let rows = []
    if (this.props.nodes !== undefined && this.props.nodes.length > 0) {
      let _this = this
      _this.props.nodes.map(function (node) {
        let checked
        if (_this.props.selectedNodes.filter(sel => sel === node.xpub)[0]) {
          checked = true
        } else {
          checked = false
        }
        
        if(node.name.startsWith(_this.state.nameFilter) && node.status.startsWith(_this.state.statusFilter)) {
          return rows.push(<Row 
            name={node.name} 
            status={node.status}
            key={node.xpub}
            xpub={node.xpub}
            checked={checked}
            selectNodes={_this.props.selectNodes}
            info={node}
          />)
        } else {
          return ''
        }
      })
    }
    let checkedLength = this.props.selectedNodes.length
    return (
      <section className='machines_list'>
        <h2 className='list_title'>All</h2>
        <Filters
          filterStatus={this.filterStatus}
          filterName={this.filterName}
          name={this.state.nameFilter}
          status={this.state.statusFilter}
        />
        <div className='table row'>
        <div className='flex_table'>
          <div className='table_row'>
            <div className={'table_row-head flex-row ' + this.props.table }>
              <div className='row_item flex-item select'>
                <div className='item_container'>
                  <div className='checkbox clearfix'>
                      <input checked={this.props.toggledControlled} type='checkbox' id={'0'} onChange={()=>{this.props.totalSelector(!this.props.toggledControlled)}} />
                      <label id='0' htmlFor={'0'} ></label>
                  </div>
                </div>
              </div>
              
              <div className='row_item flex-item name'>
                <div className='item_container'>Name</div>
              </div>
              <div className='row_item flex-item model'>
                <div className='item_container'>Status</div>
              </div>
              {/*<div className='row_item flex-item tag'>
                <div className='item_container'>Tags</div>
              </div>*/}
              <div className='row_item flex-item icon'></div>
              <div className='table_action'>
                    <button className='action_refresh' onClick={() => this.getAllNodes()}>
                        <span className='icon-ccw'></span>
                    </button>
                    <button className='action_orchestrate' onClick={()=>{this.props.manageModal('orchestrationModal', true)}}>
                        <span>{checkedLength}</span>Orchestrate
                    </button>
                    <button className='action_recovery' onClick={()=>{this.props.manageModal('recoveryModal', true)}}>
                        <span>{checkedLength}</span>Recovery
                    </button>
                </div>
            </div>
          </div>
          {rows}
        </div>
        </div>
      </section>
    )
  }
}

export default Home