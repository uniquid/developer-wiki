import axios from 'axios'
import Config from '../../config'

function getImprinterWorker (endpoint, params) {
  return new Promise(function (resolve, reject) {
    axios.get(Config.imprinterApiUrl + endpoint)
    .then(function (res) {
      resolve(res)
    })
    .catch(function (err) {
      reject(err)
    })
  })
}

function postImprinterWorker (endpoint, params) {
	return new Promise (function (resolve, reject) {
		axios.post(Config.imprinterApiUrl + endpoint, params)
		.then(function (res) {
			resolve(res)
		})
		.catch(function(err) {
			reject(err)
		})
	})
}

function deleteImprinterWorker (endpoint, params) {
	return new Promise (function (resolve, reject) {
		axios.delete(Config.imprinterApiUrl + endpoint, params)
		.then(function (res) {
			resolve(res)
		})
		.catch(function(err) {
			reject(err)
		})
	})
}

const ImprinterWorker = {
  get: getImprinterWorker,
  post: postImprinterWorker,
	delete: deleteImprinterWorker
}

export default ImprinterWorker
