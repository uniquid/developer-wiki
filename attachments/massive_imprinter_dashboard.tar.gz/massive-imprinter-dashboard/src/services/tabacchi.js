import axios from 'axios'
import Config from '../../config'

function getTabacchiWorker (endpoint) {
    return new Promise (function (resolve, reject) {
      axios.get(Config.tabacchiApiUrl + endpoint)
      .then (function (res) {
          resolve(res)
      })
      .catch (function (err) {
          reject(err)
      })
    })
}

function postTabacchiWorker (endpoint, params) {
	return new Promise (function (resolve, reject) {
		axios.post(Config.imprinterApiUrl + endpoint, params)
		.then(function (res) {
			resolve(res)
		})
		.catch(function(err) {
			reject(err)
		})
	})
}

const TabacchiWorker = {
  get: getTabacchiWorker,
  post: postTabacchiWorker
}

export default TabacchiWorker
