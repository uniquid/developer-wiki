#!/bin/sh


#export CLASSPATH=$CLASSPATH:oauth-server-0.1-RC1-SNAPSHOT-jar-with-dependencies.jar
export CLASSPATH=$CLASSPATH:.

java -Xmx2048m -Xms512m -Dorg.slf4j.simpleLogger.defaultLogLevel=info -cp $CLASSPATH -jar massive-imprinter-0.1-RC1-SNAPSHOT-jar-with-dependencies.jar appconfig.properties
