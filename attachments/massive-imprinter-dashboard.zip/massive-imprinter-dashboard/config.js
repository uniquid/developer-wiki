var Config = {
  imprinterApiUrl: 'http://[put here address of your massive imprinter backend]:8080/api/v1/',
  tabacchiApiUrl: 'http://52.225.217.168:8000/'
}

module.exports = Config
