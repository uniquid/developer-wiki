import React, {Component} from 'react'
import OrchRow from '../../components/table/orchestratorRow'
import ImprinterWorker from '../../services/imprinter'

class Orchestrators extends Component {
    constructor () {
        super()
        this.getAllOrchestrators = this.getAllOrchestrators.bind(this)
        this.deleteOrchestrator = this.deleteOrchestrator.bind(this)
    }

    getAllOrchestrators () {
        let _this = this
        ImprinterWorker.get('orchestrators')
        .then(function (res) {
            _this.props.getAllOrchestrators(res.data)
        })
    }

    deleteOrchestrator(name, xpub) {
        let _this = this
        ImprinterWorker.delete('orchestrators/' + xpub, {name: name})
        .then (function (res){
            _this.getAllOrchestrators()
        })
    }

    render() {
        let rows = []
         if (this.props.orchestrators !== undefined && this.props.orchestrators.length > 0) {
            let _this = this
            this.props.orchestrators.map(function (orch) {
                return rows.push(<OrchRow 
                name={orch.name} 
                xpub={orch.xpub}
                key={orch.xpub}
                deleteOrchestrator={_this.deleteOrchestrator}
                />)
            })
        }
        return (
        <section className='machines_list'>
            <h2 className='list_title'>Orchestrators List</h2>
            <div className='form row'>
                <div className='medium-4 columns'>
                    <div className='form_item'>
                        <label htmlFor='name'>Name</label>
                        <input onChange={this.props.addOrchestratorName} value={this.props.newOrchestrator.name} placeholder='Add name' id='name' />
                    </div>
                </div>
                <div className='medium-4 columns'>
                    <div className='form_item'>
                        <label htmlFor='xpub'>xPub</label>
                        <input onChange={this.props.addOrchestratorXpub} value={this.props.newOrchestrator.xpub} placeholder='Add xpub' id='xpub' />
                    </div>
                </div>
                <button onClick={()=>{this.props.manageModal('addOrchestratorModal', true)}}>Add Orchestrator</button>
            </div>
            <div className='table row'>
                <div className='flex_table'>
                <div className='table_row'>
                    <div className='table_row-head flex-row'>
                    <div className='row_item flex-item select'></div>
                    <div className='row_item flex-item name'>
                        <div className='item_container'>Name</div>
                    </div>
                    <div className='row_item flex-item model'>
                        <div className='item_container'>xPub</div>
                    </div>
                    <div className='row_item flex-item icon'></div>
                    </div>
                </div>
                {rows}
            </div>
            </div>
        </section>
    )
    }
}

export default Orchestrators