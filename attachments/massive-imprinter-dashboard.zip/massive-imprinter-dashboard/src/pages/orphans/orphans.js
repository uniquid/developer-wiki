import React from 'react'
import Filters from '../../components/filters/filters'

const Orphans = () => (
    <section className='machines_list'>
        <h2 className='list_title'>Orphans</h2>
        <Filters />
        <div className='table row'>
            <div className='flex_table'>
            <div className='table_row'>
                <div className='table_row-head flex-row'>
                <div className='row_item flex-item select'></div>
                <div className='row_item flex-item name'>
                    <div className='item_container'>Name</div>
                </div>
                <div className='row_item flex-item model'>
                    <div className='item_container'>Model</div>
                </div>
                <div className='row_item flex-item tag'>
                    <div className='item_container'>Tags</div>
                </div>
                <div className='row_item flex-item icon'></div>
                </div>
            </div>
            <div className='table_row'>
                <div className='table_row-container'>
                <div className='table_row-single flex-row'>
                    <div className='row_item flex-item select'>
                    <div className='item_container'>
                    <div className='checkbox clearfix'>
                        <input type='checkbox' id='0' />
                        <label htmlFor='0'></label>
                    </div>
                    </div>
                </div>
                    <div className='row_item flex-item name'>
                    <div className='item_container'>
                        nome
                    </div>
                    </div>
                    <div className='row_item flex-item model'>
                    <div className='item_container'>
                        <span>modello</span>
                    </div>
                    </div>
                    <div className='row_item flex-item tag'>
                    <div className='item_container'><span className='active'>tag</span></div>
                    </div>
                    <div className='row_item flex-item icon'>
                    <div className='item_container'>
                        <div className='icon_container'>
                        <div className='container node_actions'>
                            <span className='button renew'>send token</span>
                            <span className='icon-eye'></span>
                            <span className='icon-trash'></span>
                        </div>
                        </div>
                    </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
        </div>
    </section>
)

export default Orphans