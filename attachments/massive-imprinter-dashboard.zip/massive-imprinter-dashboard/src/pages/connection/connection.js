import React, { Component } from 'react'
import Hero from '../../components/hero/hero'
import Modal from 'react-modal'
import { connect } from 'react-redux'
import {selectAllAction, resetSelectedNodesAction, selectNodesAction, getAllNodesAction, toggledControllerAction } from '../../core/actions/nodes'
import { getAllOrchestratorsAction } from '../../core/actions/orchestrators'
import { getBalanceAction, totalNodeInfoAction } from '../../core/actions/imprinter'
import {getBlockchainInfoAction} from '../../core/actions/blockchain'
import ErrManager from '../../components/errorManager/errorManager'
import {hasErrorAction} from '../../core/actions/error'
import {updateStatusAction} from '../../core/actions/status'
import {updateFilterAction} from '../../core/actions/filter'
import { Line } from 'rc-progress'
import ImprinterWorker from '../../services/imprinter'
import TabacchiWorker from '../../services/tabacchi'

class Connection extends Component {
    constructor() {
        super()
        this.manageModal = this.manageModal.bind(this)
        this.closeStatus = this.closeStatus.bind(this)
        this.addOrchestratorName = this.addOrchestratorName.bind(this)
        this.addOrchestratorXpub = this.addOrchestratorXpub.bind(this)
        this.totalSelector = this.totalSelector.bind(this)
        this.addOrchestator = this.addOrchestator.bind(this)
        this.getBalance = this.getBalance.bind(this)
        this.doTopup = this.doTopup.bind(this)
        this.handleTopupAmount = this.handleTopupAmount.bind(this)
        this.selectOrchestrator = this.selectOrchestrator.bind(this)
        this.closeErrorModal = this.closeErrorModal.bind(this)
        this.handleScroll = this.handleScroll.bind(this)
        this.recoveryNodes = this.recoveryNodes.bind(this)
        this.getBlockchainInfo = this.getBlockchainInfo.bind(this)
        this.state = {
            topupForm: false,
            topupFormContent: 0,
            addOrchestratorModal: false,
            orchestrationModal: false,
            txStatusModal: false,
            recoveryModal: false,
            newOrchestrator: {
                name: '',
                xpub: ''
            },
            transform: 'inactive',
            table: 'inactive'
        }
    }


    getBlockchainInfo () {
        let _this = this

        TabacchiWorker.get('nextblock')
        .then (function (res) {
            _this.props.getBlockchainInfo(res.data)
            // dispaccia lazione riguardo lo status
        })
        .catch (function (err) {
            console.log(err)
            _this.props.hasError(true, 'icon-cross2', 'Server Error', 'We are having problems reaching the server, please retry in few seconds', _this.getBlockchainInfo)
        })
    }

    handleScroll (event) {
        let scrollTop = event.srcElement.body.scrollTop
        // let itemTranslate = Math.min(0, scrollTop/3 - 60)
        let _this = this
        if (scrollTop < 200) {
            _this.setState({
                ..._this.state,
                transform: 'inactive'
            })
        } else {
            _this.setState({
                ..._this.state,
                transform: 'active'
            })
        } 

        if (scrollTop < 561) {
           _this.setState({
                ..._this.state,
                table: 'inactive',
            }) 
        } else {
           _this.setState({
                ..._this.state,
                table: 'active',
            })   
        }
    }   

    componentDidMount() {
        window.addEventListener('scroll', this.handleScroll)
        this.getBalance()
        this.getBlockchainInfo()
    }

    componentDidUpdate (prevProps) {   
        let _this = this
        if (prevProps.blockchain !== this.props.blockchain) {
            if (this.props.blockchain.status === 0) {
                return setTimeout(_this.getBlockchainInfo, Number(this.props.blockchain.timeout * 1000))
            } 
            else {
                return
            }
        } 
    }

    closeErrorModal () {
        this.props.hasError(false, '', '', '')
    }

    addOrchestator() {
        let _this = this
        ImprinterWorker.post('orchestrators/' + this.state.newOrchestrator.xpub, {
          name: this.state.newOrchestrator.name
        })
        .then(function (res) {
            ImprinterWorker.get('orchestrators')
            .then(function (res) {
                _this.props.getAllOrchestrators(res.data)
                _this.manageModal('addOrchestratorModal', false)
                _this.setState({
                    ..._this.state,
                    newOrchestrator: {
                        name: '',
                        xpub: ''
                    }
                })
            })
        })
        .catch(function (err) {
            _this.manageModal('addOrchestratorModal', false)
            _this.props.hasError(true, 'icon-cross2', 'Server Error', 'We are having problems reaching the server, please retry in few seconds', _this.addOrchestator)
        })  
    }

    /* IMPRINTER BALANCE */
    getBalance() {
        let _this = this
        ImprinterWorker.get('nodeinfo')
        .then(function (res) {
            _this.props.getBalance(res.data)
        })
        .catch(function (err) {
            _this.props.hasError(true, 'icon-cross2', 'Server Error', 'We are having problems reaching the server, please retry in few seconds', _this.getBalance)
        })
    }

    handleTopupAmount(e) {
        this.setState({...this.state, topupFormContent: e.target.value})
    }

    doTopup() {
        let _this = this
        ImprinterWorker.get('nodeinfo')
        .then(function(res) {
            TabacchiWorker.post('topup', {
                address: res.data.topupAddress,
                amount: _this.state.topupFormContent
            })
            .then((res) => {
                _this.getBalance()
                _this.manageModal('topupForm', false)
            }).catch(err => console.error(err))
        }).catch(function(err) {
            console.error(err)
        })
    }

    /* TOTAL SELECTOR */
    totalSelector(status) {
        let _this = this
        this.props.toggleController(status)
        if (!this.props.toggledControlled) {
            let nodes = _this.props.nodes
            .filter(node => node.name.startsWith(_this.props.filter.name) && node.status.startsWith(_this.props.filter.status))
            .filter(node => node.status !== 'ORCHESTRATED' && node.status !== 'CREATED')
            this.props.selectAll(nodes)  
        } else {
            _this.props.resetSelectedNodes()
        }
    }


    // OPEN CLOSE MODAL
    manageModal(param, status) {
         if (param === 'addOrchestratorModal') {
            this.setState({ ...this.state, addOrchestratorModal: status }) 
        } else if (param === 'orchestrationModal') {
            this.setState({ ...this.state, orchestrationModal: status }) 
        } else if (param === 'topupForm') {
            this.setState({ ...this.state, topupForm: status }) 
        } else if (param === 'recoveryModal') {
            this.setState({ ...this.state, recoveryModal: status }) 
        }
    }

    closeStatus(param, status) {
      if (param === 'orchestrationModal') {
        this.setState({ 
            ...this.state, 
            txStatusModal: false,
            orchestrationModal: status
         })
      } else {
         this.setState({ 
            ...this.state, 
            txStatusModal: false,
            recoveryModal: status
         }) 
      }
    }

    /* ADD ORCHESTRATOR */
    addOrchestratorName(e) {
        event.preventDefault()
        let newOrch = Object.assign({}, this.state.newOrchestrator)
        newOrch.name = e.target.value
        this.setState({ ...this.state, newOrchestrator: newOrch })
    }

    addOrchestratorXpub(e) {
        event.preventDefault()
        let newOrch = Object.assign({}, this.state.newOrchestrator)
        newOrch.xpub = e.target.value
        this.setState({ ...this.state, newOrchestrator: newOrch })
    }

    recoveryNodes () {
        event.preventDefault()
        let _this = this
        let chunk = 10
        let nodes = []
        for (let i = 0; i < _this.props.selectedNodes.length; i+=chunk) {
            nodes[i/chunk] = []
            for (let j=0; j < chunk; j++) {
                if (_this.props.selectedNodes[i+j]) {
                  nodes[i/chunk][j] = _this.props.selectedNodes[i+j]
                }
            }
        }
        this.setState({ ...this.state, txStatusModal: 'active' })
        nodes.map(function (group) {
            group.map(function(xpub, i) {
                ImprinterWorker.post('recovery', {
                    machine: xpub
                })
                .then (function (res) {
                    console.log(res)
                    _this.props.updateStatus(res)
                })
                .catch (function (err) {
                    console.log(err)
                    _this.props.updateStatus(err)
                })
            })
           
        })
    }

    /* SEND ORCHESTRATE */
    sendTx () {
        event.preventDefault()
        let _this = this
        let chunk = 10
        let nodes = []
        for (let i = 0; i < _this.props.selectedNodes.length; i+=chunk) {
            nodes[i/chunk] = []
            for (let j=0; j < chunk; j++) {
                if (_this.props.selectedNodes[i+j]) {
                  nodes[i/chunk][j] = _this.props.selectedNodes[i+j]
                }
            }
        }
        this.setState({ ...this.state, txStatusModal: 'active' })
        nodes.map(function (group) {
            group.map(function(xpub, i) {
                ImprinterWorker.post('orchestrate', {
                    orchestrator: _this.state.selectedOrchestrator,
                    machine: xpub
                })
                .then (function (res) {
                    _this.props.updateStatus(res)
                })
                .catch (function (err) {
                    _this.props.updateStatus(err)
                })
            })
           
        })
    }

    selectOrchestrator(e) {
        event.preventDefault()
        this.setState({ ...this.state, selectedOrchestrator: e.target.value })
    }

    render() {
        let corrects = this.props.status.filter (st => st === 200).length
        let errs = this.props.status.filter(st => st !== 200).length
        let options = [<option key={'none'} value={'none'}>{'none'}</option>]
        this.props.orchestrators.map(orchestrator => options.push(<option key={orchestrator.xpub} value={orchestrator.xpub}>{orchestrator.name}</option>))
        
        return (
            <div className='App' >
                <ErrManager 
                    status={this.props.error.status}
                    icon={this.props.error.icon}
                    title={this.props.error.title}
                    message={this.props.error.message}
                    retry={this.props.error.retry}
                    close={this.closeErrorModal}
                />
                <Hero
                    blockchain={this.props.blockchain}
                    manageModal={this.manageModal}
                    state={this.state.topupForm}
                    imprinter={this.props.imprinter}
                    transform={this.state.transform}
                    status={this.props.status}
                    doTopup={this.doTopup}
                    handleTopupAmount={this.handleTopupAmount}
                    getBlockchainInfo={this.getBlockchainInfo}
                />
                {React.cloneElement(this.props.children, {
                    manageModal: this.manageModal,
                    addOrchestratorName: this.addOrchestratorName,
                    addOrchestratorXpub: this.addOrchestratorXpub,
                    getAllNodes: this.props.getAllNodes,
                    nodes: this.props.nodes,
                    totalSelector: this.totalSelector,
                    toggleController: this.props.toggleController,
                    toggledControlled: this.props.toggledControlled,
                    getAllOrchestrators: this.props.getAllOrchestrators,
                    orchestrators: this.props.orchestrators,
                    newOrchestrator: this.state.newOrchestrator,
                    totalNodeInfo: this.props.totalNodeInfo,
                    hasError: this.props.hasError,
                    status: this.props.status,
                    table: this.state.table,
                    selectedNodes: this.props.selectedNodes,
                    selectNodes : this.props.selectNodes,
                    filter: this.props.filter,
                    updateFilter: this.props.updateFilter,
                    resetSelectedNodes: this.props.resetSelectedNodes,
                    
                })}
                <Modal ref="addOrchestrator"
                    id="addOrchestrator"
                    contentLabel='Add Orchestrator'
                    closeTimeoutMS={150}
                    isOpen={this.state.addOrchestratorModal}
                    onAfterOpen={() => { }}
                    onRequestClose={() => {this.manageModal('addOrchestratorModal', false)}}>
                    <h4>Confirm new Orchestrator</h4>
                    You are adding the following machine
                    <div className='content_orchestrator'>
                        <div className='orchestrator_info'>
                            <span>Name</span>
                            <o>{this.state.newOrchestrator.name}</o>
                        </div>
                        <div className='orchestrator_info'>
                            <span>xPub</span>
                            <o>{this.state.newOrchestrator.xpub}</o>
                        </div>
                    </div>
                    <div className='modal_actions'>
                        <button className='actions_proceed' onClick={() => {this.addOrchestator()}}>Proceed</button>
                        <button className='actions_cancel' onClick={() => {this.manageModal('addOrchestratorModal', false)}} >Cancel</button>
                    </div>
                </Modal>
                
                <Modal ref="orchestrate"
                    id="orchestrate"
                    portalClassName="ReactModalPortal orchestrate"
                    contentLabel='Orchestrate'
                    closeTimeoutMS={150}
                    isOpen={this.state.orchestrationModal}
                    onAfterOpen={() => { }}
                    onRequestClose={()=>{this.manageModal('orchestrationModal', false)}}>
                    <h4>Confirm Orchestration</h4>
                    You are orchestrating <b>{this.props.selectedNodes.length}</b> new machines
                    <span className='label_orchestration'>Select the orchestrator</span>
                    <div className='orchestration_selection'>
                        <select className='select' onChange={this.selectOrchestrator}>
                            {options}
                        </select>
                    </div>
                    <div className='modal_actions'>
                        <button className='actions_proceed' onClick={() => { this.sendTx() }}>Proceed</button>
                        <button className='actions_cancel' onClick={()=>{this.manageModal('orchestrationModal', false)}} >Cancel</button>
                    </div>
                    <div className={'orchestration_status ' + this.state.txStatusModal}>
                        <h5 className='status_title'>Orchestration status</h5>
                        <div className='status_bar'>
                            <Line percent={this.props.status.length * 100 / this.props.selectedNodes.length} strokeWidth="2" strokeColor="#3FC7FA" />
                        </div>
                        <div className='status_info row collapse'>
                            <div className='medium-6 columns'>
                                <div className='info_box'>
                                    <h3>{corrects}</h3>
                                    <span>correct</span>
                                </div>
                            </div>
                            <div className='medium-6 columns'>
                                <div className='info_box'>
                                    <h3>{errs}</h3>
                                    <span>errors</span>
                                </div>
                            </div>
                        </div>
                        <div className='status_log'>
                            <h4 className='log_title'>Status Log</h4>

                        </div>
                        <div className='modal_actions'>
                            <button className='actions_cancel' onClick={()=>{this.closeStatus('orchestrationModal', false)}} >Cancel</button>
                        </div>
                    </div>
                </Modal>
                <Modal ref="recovery"
                    id="recovery"
                    portalClassName="ReactModalPortal recovery"
                    contentLabel='Recovery'
                    closeTimeoutMS={150}
                    isOpen={this.state.recoveryModal}
                    onAfterOpen={() => { }}
                    onRequestClose={()=>{this.manageModal('recoveryModal', false)}}>
                    <h4>Confirm Regeneration</h4>
                    You are regenerating <b>{this.props.selectedNodes.length}</b> machines
                    <div className='modal_actions'>
                        <button className='actions_proceed' onClick={() => { this.recoveryNodes() }}>Proceed</button>
                        <button className='actions_cancel' onClick={()=>{this.manageModal('recoveryModal', false)}} >Cancel</button>
                    </div>
                    <div className={'orchestration_status ' + this.state.txStatusModal}>
                        <h5 className='status_title'>Orchestration status</h5>
                        <div className='status_bar'>
                            <Line percent={this.props.status.length * 100 / this.props.selectedNodes.length} strokeWidth="2" strokeColor="#3FC7FA" />
                        </div>
                        <div className='status_info row collapse'>
                            <div className='medium-6 columns'>
                                <div className='info_box'>
                                    <h3>{corrects}</h3>
                                    <span>correct</span>
                                </div>
                            </div>
                            <div className='medium-6 columns'>
                                <div className='info_box'>
                                    <h3>{errs}</h3>
                                    <span>errors</span>
                                </div>
                            </div>
                        </div>
                        <div className='status_log'>
                            <h4 className='log_title'>Status Log</h4>

                        </div>
                        <div className='modal_actions'>
                            <button className='actions_cancel' onClick={()=>{this.closeStatus('recoveryModal', false)}} >Cancel</button>
                        </div>
                    </div>
                </Modal>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        error: state.error,
        nodes: state.nodes,
        orchestrators: state.orchestrators,
        toggledControlled: state.toggledControlled,
        imprinter: state.imprinter,
        status: state.status,
        filter:state.filter,
        blockchain: state.blockchain,
        selectedNodes: state.selectedNodes
    }
}

const mapDispatchToProps = (dispatch) => {
    return {
        hasError: (status, icon, title, message, retry) => {
            dispatch(hasErrorAction(status, icon, title, message, retry))
        },
        getAllNodes: (nodes) => {
            dispatch(getAllNodesAction(nodes))
        },
        totalNodeInfo: (nodes) => {
            dispatch(totalNodeInfoAction(nodes))
        },
        getAllOrchestrators: (nodes) => {
            dispatch(getAllOrchestratorsAction(nodes))
        },
        toggleController: (status) => {
            dispatch(toggledControllerAction(status))
        },
        getBalance: (balance) => {
            dispatch(getBalanceAction(balance))
        },
        updateStatus: (status) => {
            dispatch(updateStatusAction(status))
        },
        updateFilter: (type, filter) => {
            dispatch(updateFilterAction(type, filter))
        },
        selectNodes: (node) => {
            dispatch(selectNodesAction(node))
        },
        resetSelectedNodes: () => {
            dispatch(resetSelectedNodesAction())
        },
        selectAll: (nodes) => {
            dispatch(selectAllAction(nodes))
        },
        getBlockchainInfo: (info) => {
            dispatch(getBlockchainInfoAction(info))
        }
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Connection)
