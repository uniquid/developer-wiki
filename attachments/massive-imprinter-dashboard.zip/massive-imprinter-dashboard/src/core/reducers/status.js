import {
  UPDATE_STATUS
} from '../actions/status'

export function status (state = [], action) {
    switch (action.type) {
        case UPDATE_STATUS:
            console.log(action.status.status)
            if (action.status.status === 200) {
                return [
                    ...state,
                    action.status.status
                ]      
            } else {
                return [
                    ...state,
                    400
                ]
            }
        default:
        return state
  }
}
