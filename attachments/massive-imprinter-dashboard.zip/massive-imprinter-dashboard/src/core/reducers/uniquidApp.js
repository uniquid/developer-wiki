import { combineReducers } from 'redux'
import {nodes, toggledControlled, selectedNodes} from './nodes'
import {orchestrators} from './orchestrators'
import {imprinter} from './imprinter'
import {status} from './status'
import {filter} from './filter'
import {error} from './error'
import {blockchain} from './blockchain'

const uniquidApp = combineReducers({
  nodes,
  orchestrators,
  imprinter,
  toggledControlled,
  error,
  status,
  selectedNodes,
  filter,
  blockchain
})

export default uniquidApp
