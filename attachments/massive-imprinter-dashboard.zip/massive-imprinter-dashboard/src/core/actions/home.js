export const ACTIVATE_CONNECTION = 'ACTIVATE_CONNECTION'
export const DEACTIVATE_CONNECTION = 'DEACTIVATE_CONNECTION'
export const UPDATE_STATUS = 'UPDATE_STATUS'
export const INCREMENT_TAIL = 'INCREMENT_TAIL'
export const DECREMENT_TAIL = 'DECREMENT_TAIL'
export const ADD_SOCKET = 'ADD_SOCKET'
export const VERIFY_AUTH = 'VERIFY_AUTH'
export const ADD_IP = 'ADD_IP'
export const ADD_SESSIONID = 'ADD_SESSIONID'
export const IS_SYNCED = 'IS_SYNCED'

export const addTail = (msg) => {
  return {
    type: 'INCREMENT_TAIL',
    msg
  }
}

export const removeTail = (index) => {
  return {
    type: 'DECREMENT_TAIL',
    index
  }
}

export const addIpAction = (ip) => {
  return {
    type: 'ADD_IP',
    ip
  }
}

export const addSessionIdAction = (val) => {
  return {
    type: 'ADD_SESSIONID',
    val
  }
}

export const verifyAuthAction = (auth) => {
  return {
    type: 'VERIFY_AUTH',
    auth
  }
}

export const isSyncedAction = (status, percent, message) => {
  let res = {
    status: status,
    percent: percent,
    message: message
  }
  return {
    type: 'IS_SYNCED',
    res
  }
}

export const updateConnectionAction = (status) => {
  if (status === 1) {
    status = 'Connected'
    return {
      type: 'ACTIVATE_CONNECTION',
      status
    }
  } else {
    status = 'Disconnected'
    return {
      type: 'DEACTIVATE_CONNECTION',
      status
    }
  }
}

export const addSocketAction = (socket) => {
  return {
    type: 'ADD_SOCKET',
    socket
  }
}

export const connection = (status) => {
  return {
    type: 'ACTIVATE_CONNECTION',
    status
  }
}

export const disconnection = (status) => {
  return {
    type: 'DEACTIVATE_CONNECTION',
    status
  }
}
