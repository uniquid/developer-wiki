export const UPDATE_FILTER = 'UPDATE_FILTER'

export const updateFilterAction = (name, filter) => {
  return {
    type: 'UPDATE_FILTER',
    filter,
    name
  }
}