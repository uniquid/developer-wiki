export const GET_BLOCKCHAIN_INFO = 'GET_BLOCKCHAIN_INFO'

export const getBlockchainInfoAction = (info) => {
  return {
    type: 'GET_BLOCKCHAIN_INFO',
    info
  }
}
