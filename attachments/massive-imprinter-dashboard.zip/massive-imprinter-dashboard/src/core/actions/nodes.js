export const GET_ALL_NODES = 'GET_ALL_NODES'
// export const TOGGLE_NODE = 'TOGGLE_NODE'
export const TOGGLE_CONTROLLER = 'TOGGLE_CONTROLLER'
export const SELECT_NODE = 'SELECT_NODE'
export const RESET_SELECTION = 'RESET_SELECTION'
export const SELECT_ALL = 'SELECT_ALL'

export const getAllNodesAction = (nodes) => {
  return {
    type: 'GET_ALL_NODES',
    nodes
  }
}

export const resetSelectedNodesAction = () => {
  return {
    type: 'RESET_SELECTION'
  }
}

export const selectAllAction = (nodes) => {
  return {
    type: 'SELECT_ALL',
    nodes
  }
}

export const selectNodesAction = (node) => {
  return {
    type: 'SELECT_NODE',
    node
  }
}

// export const toggledNodeAction = (status, xpub) => {
//   let node = {
//     status, 
//     xpub
//   }
//   return {
//     type: 'TOGGLE_NODE',
//     node
//   }
// }

export const toggledControllerAction = (status) => {
  return {
    type: 'TOGGLE_CONTROLLER',
    status
  }
}

