/* @flow */

import React, { Component } from 'react'
import {Router, Route, browserHistory, Link} from 'react-router'
import Home from './pages/home/home'
import Orchestrators from './pages/orchestrators/orchestrators'
import Orphans from './pages/orphans/orphans'
import Imprinted from './pages/imprinted/imprinted'
import Connection from './pages/connection/connection'

const NotFound = () => (
  <div className='notFound'>
    <span className='notFound_monkey'></span>
    <h1>Look behind you, a three headed monkey!</h1>
    <Link className='notFound_home' to={'/'}>Back to home</Link>
  </div>
)

class App extends Component {
  render () {
    return (
      <Router history={browserHistory}>
        <Route component={Connection}>
          <Route path='/' component={Home} />
          <Route path='/orchestrators' component={Orchestrators} />
          <Route path='/orphans' component={Orphans} />
          <Route path='/imprinted' component={Imprinted} />
          <Route path='*' component={NotFound} />
        </Route>
      </Router>
    )
  }
}

export default App
