import React from 'react'

const OrchRow = (props) => (
    <div className='table_row' key={props.xpub}>
        <div className='table_row-container'>
            <div className='table_row-single flex-row'>
                <div className='row_item flex-item select'>
                    <div className='item_container'>
                        <div className='checkbox clearfix'>
                            <input type='checkbox' id='0' />
                            <label htmlFor='0'></label>
                        </div>
                    </div>
                </div>
                <div className='row_item flex-item name'>
                    <div className='item_container'>
                        {props.name}
                    </div>
                </div>
                <div className='row_item flex-item xpub'>
                    <div className='item_container'>
                        <span>{props.xpub}</span>
                    </div>
                </div>
                <div className='row_item flex-item icon'>
                    <div className='item_container'>
                        <div className='icon_container'>
                            <div className='container node_actions'>
                                <span onClick={() => {props.deleteOrchestrator(props.name, props.xpub)}} className='icon-trash'></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
)

export default OrchRow