import React from 'react'
import {Link} from 'react-router'

const Hero = (props) => {
  let countdown
  var timer = props.blockchain.timeout
  return (
    <section className='header'>
        <header className={'header_mini ' + props.transform }>
          <span className='mini_logo'></span>
          <o>Massive Imprinter</o>
          <button onClick={()=>{props.manageModal('topupForm', true)}}>Make Topup</button>
          <div className={props.state ? 'topup_amount active': 'topup_amount' }>
            <input onChange={props.handleTopupAmount} placeholder='Insert the amount' />
            <button onClick={()=>{props.manageModal('topupForm', false)}}><span className='icon-cross2'></span></button>
            <button onClick={props.doTopup}><span className='icon-check2'></span></button>
          </div>
          <div className={props.blockchain.status ? 'mini_info' : 'mini_info active' }>
              <div className='loader'>
                <div className='pacman'>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                  <div></div>
                </div>
              </div>
              <h5 className="title_mining">Next Block <span>~ {props.blockchain.timeout || 0} sec</span></h5>
              
          </div>
          <div className={props.blockchain.status ? 'mini_info_nomine active' : 'mini_info_nomine' }>
              <span className='icon-check2'></span>
              <h5>All block mined!</h5>
              <button className='button_check' onClick={()=>{props.getBlockchainInfo()}}><span className='icon-ccw'></span></button>
          </div>
        </header>
        <div className={'header_secondary ' + props.transform}>
          <ul className='secondary_list'>
            <li className='list_item'>
              balance <span>{props.imprinter.balance / 100000 || 0}</span>
            </li>
            <li className='list_item'>
              nodes <span>{props.imprinter.totalNodes || 0}</span>
            </li>
            <li className='list_item'>
              CREATED <span>{props.imprinter.totalCreated || 0}</span>
            </li>
            <li className='list_item'>
              Imprinted <span>{props.imprinter.totalImprinted || 0}</span>
            </li>
            <li className='list_item'>
              Orchestrated <span>{props.imprinter.totalOrchestrated || 0}</span>
            </li>
          </ul>
        </div>
        <div className='header_data'>
            <h3>Overview</h3>
          <div className='data_unit'>
            <h4 className='unit_title'>Balance</h4>
            <h2 className='unit_value'>{props.imprinter.balance / 100000} <span>mBTC</span></h2>
          </div>
          <div className='data_unit'>
            <h4 className='unit_title'>Total Nodes</h4>
            <h2 className='unit_value'>{props.imprinter.totalNodes || 0}</h2>
          </div>
          <div className='data_unit'>
            <h4 className='unit_title'>CREATED</h4>
            <h2 className='unit_value'>{props.imprinter.totalCreated || 0}</h2>
          </div>
          <div className='data_unit'>
            <h4 className='unit_title'>Imprinted</h4>
            <h2 className='unit_value'>{props.imprinter.totalImprinted || 0}</h2>
          </div>
          <div className='data_unit'>
            <h4 className='unit_title'>Orchestrated</h4>
            <h2 className='unit_value'>{props.imprinter.totalOrchestrated || 0}</h2>
          </div>
        </div>
        <div className='header_menu'>
          <ul className='menu_list'>
            <li className='list_item'>
              <Link activeClassName="active" to='/'>Machines</Link>
            </li>
            {/*<li className='list_item'>
              <Link activeClassName="active" to='/imprinted'>Imprinted Machines</Link>
            </li>
            <li className='list_item'>
              <Link activeClassName="active" to='/orphans'>Orphans Machines</Link>
            </li>*/}
            <li className='list_item'>
              <Link activeClassName="active" to='/orchestrators'>Orchestrators</Link>
            </li>
          </ul>
        </div>
    </section>
  )
}

export default Hero