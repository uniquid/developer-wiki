import React from 'react'

const Filters = (props) => (
    <div className='list_filter row'>
        <div className='medium-4 columns'>
            <div className='filter_item'>
                <label>Name</label>
                <input placeholder='Nome della machine' onChange={props.filterName}/>
            </div>
        </div>
        <div className='medium-4 columns'>
            <div className='filter_item'>
                <label>Filter</label>
                <select value={props.status} onChange={props.filterStatus}>
                    <option value="ALL">All</option>
                    <option value="CREATED">Created</option>
                    <option value="IMPRINTED">Imprinted</option>
                    <option value="ORCHESTRATED">Orchestrated</option>
                </select>
            </div>
        </div>
        <div className='medium-4 columns'>
            <div className='filter_item last'>
                <label>Tag</label>
                <input placeholder='Insert Tag'/>
            </div>
        </div>
    </div>
)

export default Filters