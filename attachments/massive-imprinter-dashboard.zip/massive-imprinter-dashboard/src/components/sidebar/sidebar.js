import React, {Component} from 'react'
import Contexts from '../../modules/sidebar.modules/contexts'
import Imprinter from '../../modules/sidebar.modules/imprinter'
import axios from 'axios'
import uidMethods from '../../uidMethods'
import {Link} from 'react-router'
import {browserHistory} from 'react-router'

class Sidebar extends Component {
  constructor () {
    super()
    this.handleUserInput = this.handleUserInput.bind(this)
    this.handleChange = this.handleChange.bind(this)
    this.toggle = this.toggle.bind(this)
    this.deleteContext = this.deleteContext.bind(this)
    this.state = {
      filterText: '',
      visible: false,
      successNotificationActive: false,
      errorNotificationActive: false
    }
  }

  toggleSuccessNotification () {
    this.setState({
      successNotificationActive: !this.state.successNotificationActive
    })
  }

  toggleErrorNotification () {
    this.setState({
      errorNotificationActive: !this.state.errorNotificationActive
    })
  }

  componentDidMount () {
    if (this.props.connectionStatus !== 'Connected') {
      browserHistory.replace('/')
    } else {
      this.props.sendMessage(uidMethods.getContexts, '', 'getContexts')
    }
  }

  componentDidUpdate (prevProps, prevState) {
    if (prevProps.connectionStatus !== this.props.connectionStatus) {
      if (this.props.connectionStatus === 'Connected') {
        this.props.sendMessage(uidMethods.getContexts, '', 'getContexts')
      }
    }
  }

  handleChange (event) {
    this.handleUserInput(event.target.value)
  }

  deleteContext (context) {
    let contextJSON = JSON.stringify(context)
    var config = {
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Origin': '104.211.4.111'
      }
    }
    axios.delete('http://10.0.0.11:8080/UID_IAM_Registry/rest/Registry/context/all', contextJSON, config)
    .then(res => {
      if (res.status >= 200 && res.status < 300) {
        this.setState({
          successNotificationActive: !this.state.successNotificationActive
        })
        this.props.deleteContext(context)
      }
    })
    .catch(error => {
      this.setState({
        errorNotificationActive: !this.state.errorNotificationActive
      })
    })
  }

  toggle () {
    this.setState({
      visible: !this.state.visible
    })
  }

  handleUserInput (filterText) {
    this.setState({
      filterText: filterText
    })
  }

  render () {
    return (
      <aside id="sidebar_management">
          <Contexts nameParam={this.props.nameParam} deleteContext={this.deleteContext} contexts={this.props.contexts} handleChange={this.handleChange} toggle={this.toggle} visible={this.state.visible} handleUserInput={this.handleUserInput} filterText={this.state.filterText}/>
          <Imprinter />
      </aside>
    )
  }
}

export default Sidebar
